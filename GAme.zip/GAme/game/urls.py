from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import SaveScore

urlpatterns = [
  path('', views.index,name='index'),
  # path('about', views.about,name='about'),
  path('game/', views.game,name='game'),
  #path('about', questionView.as_view(),name='about'),
  path('about/', views.about,name='about'),
  # path('login', views.login,name='login'),
  path('savescore/', SaveScore, name='savescore'),

]+static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)