from django.shortcuts import render
from django.http import HttpResponse
import  random
from .models import quiz
from django.views.decorators.csrf import csrf_exempt
#from django.utils import simplejson
from .models import quiz

def index(request):
    return render(request,'index.html')
def game(request):
    obj=quiz.objects.all()
    # list = [1,2,3,'String1']
    # json_list = simplejson.dumps(list)    
    # #random_item = random.choice(obj)
    # for obj in obje:
    #     mylist = [obj.option1, obj.option2, obj.option3,obj.option4]
    #     #mylist = ['a','b','v','f']
    #     random.shuffle(mylist)
    return render(request,'game.html',{'obj': obj})

def about(request):
    return render(request,'about.html')
# Create your views here.


@csrf_exempt
def SaveScore(request):
    if request.method == 'POST':
        print("yes")
        import pdb;pdb.set_trace()

        quiz_obj =quiz.objects.create(
        question = request.POST['question'], 
        option1= request.POST['option1'],
        option2=request.POST['option2'],
        option3=request.POST['option3'],
        option4=request.POST['option4'],
        correct=request.POST['target'],
        point=request.POST['point'],
        level=request.POST['level'],
    )
    quiz_obj.save()
    return render(request,'about.html')
