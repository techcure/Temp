from django.contrib import admin
from .models import quiz
# Register your models here.
admin.site.register(quiz)

